/* ==========================================================================
 * parser.y -- Syntax analyser, symbol table and intermediate code generator
 *             for the CALC calculator language.
 * Course: BCSE307P Compiler Design Lab
 *
 * Build:  bison -d parser.y        ->  parser.tab.c, parser.tab.h
 *         flex  lexer.l            ->  lex.yy.c
 *         gcc parser.tab.c lex.yy.c -o calc -lm
 *
 * The grammar is an LALR(1) expression grammar. Ambiguity in the raw rule
 *     expr : expr '+' expr | expr '*' expr | ...
 * is resolved by the %left / %right precedence declarations below rather than
 * by stratifying the grammar into expr / term / factor. This is the standard
 * yacc idiom and keeps the attribute actions readable.
 *
 * Translation scheme: every `expr` synthesises one attribute, `place`, the
 * name of the temporary or variable holding its value. Each production emits
 * one quadruple and returns a fresh temporary.
 * ========================================================================== */

%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_SYMBOLS 256
#define MAX_QUADS   1024

extern int  yylex(void);
extern int  yylineno;
extern int  lex_errors;
extern FILE *yyin;

void yyerror(const char *msg);

/* ---------------------------------------------------------------- symbols */
typedef struct {
    char name[64];
    int  initialised;
    int  first_line;
    int  writes;
    int  reads;
    int  address;
} Symbol;

static Symbol symtab[MAX_SYMBOLS];
static int    symbol_count = 0;
static int    semantic_errors = 0;

static int sym_lookup(const char *name) {
    for (int i = 0; i < symbol_count; i++)
        if (strcmp(symtab[i].name, name) == 0) return i;
    return -1;
}

static int sym_install(const char *name, int line) {
    int i = sym_lookup(name);
    if (i >= 0) return i;
    if (symbol_count >= MAX_SYMBOLS) {
        fprintf(stderr, "fatal: symbol table overflow\n");
        exit(1);
    }
    i = symbol_count++;
    strncpy(symtab[i].name, name, sizeof(symtab[i].name) - 1);
    symtab[i].name[sizeof(symtab[i].name) - 1] = '\0';
    symtab[i].initialised = 0;
    symtab[i].first_line  = line;
    symtab[i].writes = 0;
    symtab[i].reads  = 0;
    symtab[i].address = i * 8;          /* 8 bytes per numeric slot */
    return i;
}

/* ------------------------------------------------------------- quadruples */
typedef struct {
    char op[12];
    char arg1[64];
    char arg2[64];
    char result[64];
} Quad;

static Quad quads[MAX_QUADS];
static int  quad_count = 0;
static int  temp_count = 0;

static char *newtemp(void) {
    char *t = (char *) malloc(16);
    sprintf(t, "t%d", ++temp_count);
    return t;
}

static void emit(const char *op, const char *a1, const char *a2, const char *res) {
    if (quad_count >= MAX_QUADS) {
        fprintf(stderr, "fatal: too many instructions\n");
        exit(1);
    }
    Quad *q = &quads[quad_count++];
    snprintf(q->op,     sizeof(q->op),     "%s", op  ? op  : "-");
    snprintf(q->arg1,   sizeof(q->arg1),   "%s", a1  ? a1  : "-");
    snprintf(q->arg2,   sizeof(q->arg2),   "%s", a2  ? a2  : "-");
    snprintf(q->result, sizeof(q->result), "%s", res ? res : "-");
}

/* Render a numeric literal as its own `place`. */
static char *numplace(double v) {
    char *buf = (char *) malloc(32);
    if (v == (long long) v) sprintf(buf, "%lld", (long long) v);
    else                    sprintf(buf, "%g", v);
    return buf;
}

static void print_tac(void);
static void print_quads(void);
static void print_symtab(void);
%}

%locations
%define parse.error verbose

%union {
    double  num;
    char   *id;
    char   *place;
}

%token <num>   NUM
%token <id>    ID
%token         INPUT PRINT

%type  <place> expr

/* Precedence, lowest first. '^' is declared after UMINUS so that it binds
 * more tightly, making  -3 ^ 2  parse as  -(3 ^ 2).                        */
%left       '+' '-'
%left       '*' '/' '%'
%precedence UMINUS
%right      '^'

%%

program
    : stmt_list
    ;

stmt_list
    : stmt_list stmt
    | %empty
    ;

stmt
    : ID '=' expr ';'
        {
            int i = sym_install($1, @1.first_line);
            symtab[i].initialised = 1;
            symtab[i].writes++;
            emit("=", $3, NULL, $1);
            free($1);
        }
    | INPUT ID ';'
        {
            int i = sym_install($2, @1.first_line);
            symtab[i].initialised = 1;
            symtab[i].writes++;
            emit("input", NULL, NULL, $2);
            free($2);
        }
    | PRINT expr ';'
        {
            emit("print", $2, NULL, "-");
        }
    | error ';'
        {   /* panic-mode recovery: discard the bad statement and carry on */
            yyerrok;
        }
    ;

expr
    : expr '+' expr   { $$ = newtemp(); emit("+", $1, $3, $$); }
    | expr '-' expr   { $$ = newtemp(); emit("-", $1, $3, $$); }
    | expr '*' expr   { $$ = newtemp(); emit("*", $1, $3, $$); }
    | expr '/' expr   {
            if (strcmp($3, "0") == 0) {
                fprintf(stderr, "Semantic error at line %d: division by zero\n",
                        @2.first_line);
                semantic_errors++;
            }
            $$ = newtemp(); emit("/", $1, $3, $$);
        }
    | expr '%' expr   {
            if (strcmp($3, "0") == 0) {
                fprintf(stderr, "Semantic error at line %d: modulo by zero\n",
                        @2.first_line);
                semantic_errors++;
            }
            $$ = newtemp(); emit("%", $1, $3, $$);
        }
    | expr '^' expr   { $$ = newtemp(); emit("^", $1, $3, $$); }
    | '-' expr %prec UMINUS
                      { $$ = newtemp(); emit("uminus", $2, NULL, $$); }
    | '+' expr %prec UMINUS
                      { $$ = $2; }
    | '(' expr ')'    { $$ = $2; }
    | NUM             { $$ = numplace($1); }
    | ID              {
            int i = sym_lookup($1);
            if (i < 0 || !symtab[i].initialised) {
                fprintf(stderr,
                        "Semantic error at line %d: variable '%s' is used "
                        "before it is assigned\n", @1.first_line, $1);
                semantic_errors++;
                i = sym_install($1, @1.first_line);
                symtab[i].initialised = 1;
            }
            symtab[i].reads++;
            $$ = $1;
        }
    ;

%%

void yyerror(const char *msg) {
    fprintf(stderr, "Syntax error at line %d, column %d: %s\n",
            yylloc.first_line, yylloc.first_column, msg);
}

static void print_tac(void) {
    printf("\n========================================================\n");
    printf(" INTERMEDIATE CODE (three-address code)\n");
    printf("========================================================\n");
    for (int i = 0; i < quad_count; i++) {
        Quad *q = &quads[i];
        if (strcmp(q->op, "=") == 0)
            printf("%3d:  %s = %s\n", i + 1, q->result, q->arg1);
        else if (strcmp(q->op, "uminus") == 0)
            printf("%3d:  %s = -%s\n", i + 1, q->result, q->arg1);
        else if (strcmp(q->op, "print") == 0)
            printf("%3d:  print %s\n", i + 1, q->arg1);
        else if (strcmp(q->op, "input") == 0)
            printf("%3d:  input %s\n", i + 1, q->result);
        else
            printf("%3d:  %s = %s %s %s\n", i + 1, q->result, q->arg1, q->op, q->arg2);
    }
    printf("\nInstructions: %d   Temporaries used: %d\n", quad_count, temp_count);
}

static void print_quads(void) {
    printf("\n========================================================\n");
    printf(" QUADRUPLE TABLE\n");
    printf("========================================================\n");
    printf("%3s  %-8s%-12s%-12s%-10s\n", "#", "op", "arg1", "arg2", "result");
    printf("-----------------------------------------------\n");
    for (int i = 0; i < quad_count; i++)
        printf("%3d  %-8s%-12s%-12s%-10s\n", i + 1,
               quads[i].op, quads[i].arg1, quads[i].arg2, quads[i].result);
}

static void print_symtab(void) {
    printf("\n========================================================\n");
    printf(" SYMBOL TABLE\n");
    printf("========================================================\n");
    printf("%-12s%-10s%6s%7s%8s%7s\n",
           "Name", "Type", "Addr", "Decl@", "Writes", "Reads");
    printf("------------------------------------------------------\n");
    for (int i = 0; i < symbol_count; i++)
        printf("%-12s%-10s%6d%7d%8d%7d\n",
               symtab[i].name, "number", symtab[i].address,
               symtab[i].first_line, symtab[i].writes, symtab[i].reads);
}

int main(int argc, char **argv) {
    if (argc > 1) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 2; }
    }

    int parse_status = yyparse();

    if (parse_status != 0 || lex_errors > 0 || semantic_errors > 0) {
        fprintf(stderr, "\nCompilation failed: %d lexical, %d semantic error(s).\n",
                lex_errors, semantic_errors);
        return 1;
    }

    print_symtab();
    print_tac();
    print_quads();
    return 0;
}
