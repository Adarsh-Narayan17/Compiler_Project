#!/usr/bin/env python3
"""
================================================================================
 CALC -- A Mini Compiler for a Calculator Language
================================================================================
 Course   : BCSE307P - Compiler Design Lab
 Project  : Mini compiler supporting arithmetic expressions, variables and
            assignment statements.
 Phases   : 1. Lexical Analysis      (hand-written DFA scanner)
            2. Syntax Analysis       (recursive-descent / LL(1) parser -> AST)
            3. Semantic Analysis     (symbol table, use-before-define checks)
            4. Intermediate Code Gen (three-address code + quadruples)
            5. (bonus) Constant folding optimisation + TAC interpreter

 Usage:
     python3 calc_compiler.py  <source.calc> [options]
     python3 calc_compiler.py  --demo

 Options:
     --tokens    print the token stream produced by the lexer
     --ast       print the abstract syntax tree
     --symtab    print the symbol table
     --tac       print the three-address code       (default ON)
     --quads     print the quadruple table
     --opt       enable constant folding before code generation
     --run       execute the generated TAC and print program output
     --all       equivalent to --tokens --ast --symtab --tac --quads --run

 Grammar (unambiguous, LL(1) after left-recursion removal):

     program    -> stmt_list EOF
     stmt_list  -> stmt stmt_list | epsilon
     stmt       -> ID '=' expr ';'
                 | 'input' ID ';'
                 | 'print' expr ';'
     expr       -> term  { ('+' | '-') term }
     term       -> unary { ('*' | '/' | '%') unary }
     unary      -> ('+' | '-') unary | power
     power      -> primary [ '^' unary ]           (right associative)
     primary    -> NUMBER | ID | '(' expr ')'

 Precedence (low -> high): + -   <   * / %   <   unary + -   <   ^

 Placing `power` below `unary` makes '^' bind tighter than unary minus, so
 -3 ^ 2 parses as -(3 ^ 2) = -9, matching standard mathematical convention,
 while the right operand of '^' is a `unary` so 2 ^ -3 is still legal.
================================================================================
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

# ==============================================================================
# 0. DIAGNOSTICS
# ==============================================================================


class CompilerError(Exception):
    """Base class for every error raised by a compiler phase."""

    def __init__(self, phase: str, message: str, line: int, col: int):
        self.phase = phase
        self.message = message
        self.line = line
        self.col = col
        super().__init__(f"[{phase} error] line {line}, col {col}: {message}")


class LexicalError(CompilerError):
    def __init__(self, message, line, col):
        super().__init__("Lexical", message, line, col)


class SyntaxError_(CompilerError):
    def __init__(self, message, line, col):
        super().__init__("Syntax", message, line, col)


class SemanticError(CompilerError):
    def __init__(self, message, line, col):
        super().__init__("Semantic", message, line, col)


class ErrorReporter:
    """Collects errors so the compiler can report several at once."""

    def __init__(self, source_name: str, source_lines: List[str]):
        self.source_name = source_name
        self.source_lines = source_lines
        self.errors: List[CompilerError] = []

    def report(self, err: CompilerError) -> None:
        self.errors.append(err)

    @property
    def has_errors(self) -> bool:
        return len(self.errors) > 0

    def dump(self) -> None:
        for err in self.errors:
            print(f"{self.source_name}:{err.line}:{err.col}: {err.phase} error: "
                  f"{err.message}", file=sys.stderr)
            if 0 < err.line <= len(self.source_lines):
                text = self.source_lines[err.line - 1].rstrip("\n")
                print(f"    {text}", file=sys.stderr)
                print(f"    {' ' * max(err.col - 1, 0)}^", file=sys.stderr)
        n = len(self.errors)
        print(f"\n{n} error{'s' if n != 1 else ''} generated.", file=sys.stderr)


# ==============================================================================
# 1. LEXICAL ANALYSIS
# ==============================================================================

# Token categories recognised by the scanner.
TT_NUMBER = "NUMBER"
TT_ID = "ID"
TT_KEYWORD = "KEYWORD"
TT_OP = "OP"
TT_PUNCT = "PUNCT"
TT_EOF = "EOF"

KEYWORDS = {"input", "print"}

# Multi-character and single-character operator lexemes.
OPERATORS = {"+", "-", "*", "/", "%", "^", "="}
PUNCTUATION = {"(", ")", ";"}


@dataclass
class Token:
    """A lexeme together with its classification and source position."""
    type: str          # TT_NUMBER / TT_ID / TT_KEYWORD / TT_OP / TT_PUNCT / TT_EOF
    lexeme: str        # exact text matched in the source
    value: Any = None  # numeric value for NUMBER tokens, else None
    line: int = 0
    col: int = 0

    def __repr__(self) -> str:
        v = "" if self.value is None else f", value={self.value}"
        return f"<{self.type}, '{self.lexeme}'{v}, {self.line}:{self.col}>"


class Lexer:
    """
    Hand-written scanner implementing the DFA for the token classes of CALC.

    Transition sketch
    -----------------
        start --digit--> INT --'.'--> FRAC --digit--> FRAC   (accept NUMBER)
        start --letter|'_'--> IDENT --letter|digit|'_'--> IDENT (accept ID/KEYWORD)
        start --operator--> accept OP
        start --'(' ')' ';'--> accept PUNCT
        start --'/','/'--> LINE_COMMENT (skipped)
        start --whitespace--> start
    """

    def __init__(self, source: str, reporter: ErrorReporter):
        self.src = source
        self.pos = 0
        self.line = 1
        self.col = 1
        self.reporter = reporter
        self.tokens: List[Token] = []

    # -- character helpers ----------------------------------------------------
    def _peek(self, k: int = 0) -> str:
        i = self.pos + k
        return self.src[i] if i < len(self.src) else ""

    def _advance(self) -> str:
        ch = self.src[self.pos]
        self.pos += 1
        if ch == "\n":
            self.line += 1
            self.col = 1
        else:
            self.col += 1
        return ch

    # -- main loop ------------------------------------------------------------
    def tokenize(self) -> List[Token]:
        while self.pos < len(self.src):
            ch = self._peek()

            # 1. whitespace
            if ch in " \t\r\n":
                self._advance()
                continue

            # 2. comments:  // to end of line,  /* ... */ block
            if ch == "/" and self._peek(1) == "/":
                while self.pos < len(self.src) and self._peek() != "\n":
                    self._advance()
                continue
            if ch == "/" and self._peek(1) == "*":
                start_line, start_col = self.line, self.col
                self._advance()
                self._advance()
                closed = False
                while self.pos < len(self.src):
                    if self._peek() == "*" and self._peek(1) == "/":
                        self._advance()
                        self._advance()
                        closed = True
                        break
                    self._advance()
                if not closed:
                    self.reporter.report(LexicalError(
                        "unterminated block comment", start_line, start_col))
                continue

            start_line, start_col = self.line, self.col

            # 3. numeric literal:  digits [ '.' digits ] [ (e|E) [+|-] digits ]
            if ch.isdigit() or (ch == "." and self._peek(1).isdigit()):
                self._scan_number(start_line, start_col)
                continue

            # 4. identifier or keyword
            if ch.isalpha() or ch == "_":
                lexeme = ""
                while self._peek().isalnum() or self._peek() == "_":
                    lexeme += self._advance()
                ttype = TT_KEYWORD if lexeme in KEYWORDS else TT_ID
                self.tokens.append(Token(ttype, lexeme, None, start_line, start_col))
                continue

            # 5. operators
            if ch in OPERATORS:
                lexeme = self._advance()
                self.tokens.append(Token(TT_OP, lexeme, None, start_line, start_col))
                continue

            # 6. punctuation
            if ch in PUNCTUATION:
                lexeme = self._advance()
                self.tokens.append(Token(TT_PUNCT, lexeme, None, start_line, start_col))
                continue

            # 7. anything else is an illegal character -> report and skip
            bad = self._advance()
            self.reporter.report(LexicalError(
                f"illegal character {bad!r}", start_line, start_col))

        self.tokens.append(Token(TT_EOF, "<eof>", None, self.line, self.col))
        return self.tokens

    def _scan_number(self, start_line: int, start_col: int) -> None:
        lexeme = ""
        seen_dot = False
        while self._peek().isdigit() or (self._peek() == "." and not seen_dot):
            if self._peek() == ".":
                seen_dot = True
            lexeme += self._advance()
        # optional exponent part
        if self._peek() in ("e", "E"):
            save_pos, save_line, save_col = self.pos, self.line, self.col
            exp = self._advance()
            if self._peek() in ("+", "-"):
                exp += self._advance()
            if self._peek().isdigit():
                while self._peek().isdigit():
                    exp += self._advance()
                lexeme += exp
            else:
                # not an exponent after all -- roll the scanner back
                self.pos, self.line, self.col = save_pos, save_line, save_col

        # A digit sequence immediately followed by a letter is malformed (e.g. 12abc)
        if self._peek().isalpha() or self._peek() == "_":
            bad = lexeme
            while self._peek().isalnum() or self._peek() == "_":
                bad += self._advance()
            self.reporter.report(LexicalError(
                f"malformed number {bad!r}", start_line, start_col))
            return

        value = float(lexeme) if (seen_dot or "e" in lexeme or "E" in lexeme) else int(lexeme)
        self.tokens.append(Token(TT_NUMBER, lexeme, value, start_line, start_col))


# ==============================================================================
# 2. ABSTRACT SYNTAX TREE
# ==============================================================================


class Node:
    """Base class for every AST node."""
    line: int = 0
    col: int = 0


@dataclass
class Program(Node):
    statements: List[Node] = field(default_factory=list)


@dataclass
class Assign(Node):
    name: str
    expr: Node
    line: int = 0
    col: int = 0


@dataclass
class Print(Node):
    expr: Node
    line: int = 0
    col: int = 0


@dataclass
class Input(Node):
    name: str
    line: int = 0
    col: int = 0


@dataclass
class BinOp(Node):
    op: str
    left: Node
    right: Node
    line: int = 0
    col: int = 0


@dataclass
class UnaryOp(Node):
    op: str
    operand: Node
    line: int = 0
    col: int = 0


@dataclass
class Num(Node):
    value: Any
    line: int = 0
    col: int = 0


@dataclass
class Var(Node):
    name: str
    line: int = 0
    col: int = 0


def render_ast(node: Node, prefix: str = "", is_last: bool = True,
               is_root: bool = True) -> str:
    """Pretty-print the AST as an indented tree."""
    connector = "" if is_root else ("`-- " if is_last else "|-- ")

    if isinstance(node, Program):
        label = "Program"
        children: List[Node] = list(node.statements)
    elif isinstance(node, Assign):
        label = f"Assign ({node.name} =)"
        children = [node.expr]
    elif isinstance(node, Print):
        label = "Print"
        children = [node.expr]
    elif isinstance(node, Input):
        label = f"Input ({node.name})"
        children = []
    elif isinstance(node, BinOp):
        label = f"BinOp ({node.op})"
        children = [node.left, node.right]
    elif isinstance(node, UnaryOp):
        label = f"UnaryOp ({node.op})"
        children = [node.operand]
    elif isinstance(node, Num):
        label = f"Num {node.value}"
        children = []
    elif isinstance(node, Var):
        label = f"Var {node.name}"
        children = []
    else:
        label, children = repr(node), []

    out = prefix + connector + label + "\n"
    child_prefix = prefix if is_root else prefix + ("    " if is_last else "|   ")
    for i, child in enumerate(children):
        out += render_ast(child, child_prefix, i == len(children) - 1, False)
    return out


# ==============================================================================
# 3. SYNTAX ANALYSIS  (recursive-descent parser)
# ==============================================================================


class Parser:
    """
    Predictive recursive-descent parser.

    One procedure per non-terminal. Left recursion in `expr` and `term` is
    removed by iteration, and `^` is parsed right-associatively by recursing
    into `factor` on the right-hand side.

    Error handling uses panic-mode recovery: on a syntax error the parser
    discards tokens until it passes a ';', then resumes at the next statement.
    """

    def __init__(self, tokens: List[Token], reporter: ErrorReporter):
        self.tokens = tokens
        self.pos = 0
        self.reporter = reporter

    # -- token helpers --------------------------------------------------------
    @property
    def current(self) -> Token:
        return self.tokens[self.pos]

    def _at(self, lexeme: str) -> bool:
        return self.current.lexeme == lexeme and self.current.type != TT_EOF

    def _advance(self) -> Token:
        tok = self.current
        if tok.type != TT_EOF:
            self.pos += 1
        return tok

    def _expect(self, lexeme: str, what: str) -> Token:
        if self._at(lexeme):
            return self._advance()
        raise SyntaxError_(
            f"expected {what} '{lexeme}' but found '{self.current.lexeme}'",
            self.current.line, self.current.col)

    def _synchronise(self) -> None:
        """Panic-mode recovery: skip to just past the next ';'."""
        while self.current.type != TT_EOF:
            if self._at(";"):
                self._advance()
                return
            self._advance()

    # -- grammar rules --------------------------------------------------------
    def parse_program(self) -> Program:
        """program -> stmt_list EOF"""
        prog = Program()
        while self.current.type != TT_EOF:
            try:
                prog.statements.append(self.parse_stmt())
            except CompilerError as err:
                self.reporter.report(err)
                self._synchronise()
        return prog

    def parse_stmt(self) -> Node:
        """stmt -> ID '=' expr ';' | 'input' ID ';' | 'print' expr ';'"""
        tok = self.current

        if tok.type == TT_KEYWORD and tok.lexeme == "input":
            self._advance()
            name_tok = self.current
            if name_tok.type != TT_ID:
                raise SyntaxError_("expected a variable name after 'input'",
                                    name_tok.line, name_tok.col)
            self._advance()
            self._expect(";", "statement terminator")
            return Input(name_tok.lexeme, tok.line, tok.col)

        if tok.type == TT_KEYWORD and tok.lexeme == "print":
            self._advance()
            expr = self.parse_expr()
            self._expect(";", "statement terminator")
            return Print(expr, tok.line, tok.col)

        if tok.type == TT_ID:
            name_tok = self._advance()
            self._expect("=", "assignment operator")
            expr = self.parse_expr()
            self._expect(";", "statement terminator")
            return Assign(name_tok.lexeme, expr, name_tok.line, name_tok.col)

        raise SyntaxError_(
            f"expected a statement (identifier, 'input' or 'print') but found "
            f"'{tok.lexeme}'", tok.line, tok.col)

    def parse_expr(self) -> Node:
        """expr -> term { ('+' | '-') term }        (left associative)"""
        node = self.parse_term()
        while self._at("+") or self._at("-"):
            op_tok = self._advance()
            right = self.parse_term()
            node = BinOp(op_tok.lexeme, node, right, op_tok.line, op_tok.col)
        return node

    def parse_term(self) -> Node:
        """term -> unary { ('*' | '/' | '%') unary }    (left associative)"""
        node = self.parse_unary()
        while self._at("*") or self._at("/") or self._at("%"):
            op_tok = self._advance()
            right = self.parse_unary()
            node = BinOp(op_tok.lexeme, node, right, op_tok.line, op_tok.col)
        return node

    def parse_unary(self) -> Node:
        """unary -> ('+' | '-') unary | power"""
        if self._at("+") or self._at("-"):
            op_tok = self._advance()
            operand = self.parse_unary()
            if op_tok.lexeme == "+":
                return operand               # unary plus is the identity
            return UnaryOp("-", operand, op_tok.line, op_tok.col)
        return self.parse_power()

    def parse_power(self) -> Node:
        """power -> primary [ '^' unary ]              (right associative)"""
        node = self.parse_primary()
        if self._at("^"):
            op_tok = self._advance()
            # Recursing into `unary` keeps '^' right associative and lets the
            # right operand carry its own sign, as in  2 ^ -3.
            right = self.parse_unary()
            node = BinOp("^", node, right, op_tok.line, op_tok.col)
        return node

    def parse_primary(self) -> Node:
        """primary -> NUMBER | ID | '(' expr ')'"""
        tok = self.current

        if tok.type == TT_NUMBER:
            self._advance()
            return Num(tok.value, tok.line, tok.col)

        if tok.type == TT_ID:
            self._advance()
            return Var(tok.lexeme, tok.line, tok.col)

        if self._at("("):
            self._advance()
            node = self.parse_expr()
            self._expect(")", "closing parenthesis")
            return node

        raise SyntaxError_(
            f"expected a number, variable or '(' but found '{tok.lexeme}'",
            tok.line, tok.col)


# ==============================================================================
# 4. SYMBOL TABLE AND SEMANTIC ANALYSIS
# ==============================================================================


@dataclass
class SymbolEntry:
    name: str
    kind: str = "variable"
    dtype: str = "number"
    first_line: int = 0
    assignments: int = 0
    uses: int = 0
    address: int = 0           # offset in the (notional) activation record


class SymbolTable:
    """Flat single-scope symbol table. CALC has no blocks or functions."""

    def __init__(self):
        self.entries: Dict[str, SymbolEntry] = {}
        self._next_address = 0

    def define(self, name: str, line: int) -> SymbolEntry:
        entry = self.entries.get(name)
        if entry is None:
            entry = SymbolEntry(name=name, first_line=line,
                                address=self._next_address)
            self._next_address += 8          # 8 bytes per numeric slot
            self.entries[name] = entry
        entry.assignments += 1
        return entry

    def lookup(self, name: str) -> Optional[SymbolEntry]:
        return self.entries.get(name)

    def render(self) -> str:
        head = (f"{'Name':<12}{'Kind':<10}{'Type':<10}{'Addr':>6}"
                f"{'Decl@':>7}{'Writes':>8}{'Reads':>7}")
        lines = [head, "-" * len(head)]
        for e in self.entries.values():
            lines.append(f"{e.name:<12}{e.kind:<10}{e.dtype:<10}{e.address:>6}"
                         f"{e.first_line:>7}{e.assignments:>8}{e.uses:>7}")
        if not self.entries:
            lines.append("(empty)")
        return "\n".join(lines)


class SemanticAnalyser:
    """
    Walks the AST and checks the two static rules CALC imposes:

      S1. A variable must be assigned before it is read.
      S2. Division or modulo by a literal zero is rejected at compile time.

    It also populates the symbol table used by code generation.
    """

    def __init__(self, reporter: ErrorReporter):
        self.table = SymbolTable()
        self.reporter = reporter
        self.initialised: set[str] = set()

    def analyse(self, prog: Program) -> SymbolTable:
        for stmt in prog.statements:
            self._stmt(stmt)
        return self.table

    def _stmt(self, node: Node) -> None:
        if isinstance(node, Assign):
            self._expr(node.expr)                 # RHS is evaluated first
            self.table.define(node.name, node.line)
            self.initialised.add(node.name)
        elif isinstance(node, Print):
            self._expr(node.expr)
        elif isinstance(node, Input):
            self.table.define(node.name, node.line)
            self.initialised.add(node.name)

    def _expr(self, node: Node) -> None:
        if isinstance(node, Num):
            return

        if isinstance(node, Var):
            if node.name not in self.initialised:
                self.reporter.report(SemanticError(
                    f"variable '{node.name}' is used before it is assigned",
                    node.line, node.col))
                # Define it anyway so later phases have an entry to work with.
                self.table.define(node.name, node.line)
                self.initialised.add(node.name)
            entry = self.table.lookup(node.name)
            if entry:
                entry.uses += 1
            return

        if isinstance(node, UnaryOp):
            self._expr(node.operand)
            return

        if isinstance(node, BinOp):
            self._expr(node.left)
            self._expr(node.right)
            if node.op in ("/", "%") and isinstance(node.right, Num) \
                    and node.right.value == 0:
                self.reporter.report(SemanticError(
                    f"division by zero in '{node.op}' operation",
                    node.line, node.col))
            return


# ==============================================================================
# 5. OPTIMISATION  (constant folding on the AST)
# ==============================================================================


def fold_constants(node: Node) -> Node:
    """
    Replace every sub-expression whose operands are all literals by the literal
    result. This is the classic constant-folding transformation and it runs
    before code generation, so the emitted TAC is already simplified.
    """
    if isinstance(node, Program):
        node.statements = [fold_constants(s) for s in node.statements]
        return node

    if isinstance(node, Assign):
        node.expr = fold_constants(node.expr)
        return node

    if isinstance(node, Print):
        node.expr = fold_constants(node.expr)
        return node

    if isinstance(node, Input):
        return node

    if isinstance(node, UnaryOp):
        node.operand = fold_constants(node.operand)
        if isinstance(node.operand, Num):
            return Num(-node.operand.value, node.line, node.col)
        return node

    if isinstance(node, BinOp):
        node.left = fold_constants(node.left)
        node.right = fold_constants(node.right)
        if isinstance(node.left, Num) and isinstance(node.right, Num):
            try:
                value = apply_op(node.op, node.left.value, node.right.value)
            except ZeroDivisionError:
                return node                   # leave it; semantics reported it
            return Num(value, node.line, node.col)
        return node

    return node


def apply_op(op: str, a: Any, b: Any) -> Any:
    if op == "+":
        return a + b
    if op == "-":
        return a - b
    if op == "*":
        return a * b
    if op == "/":
        if b == 0:
            raise ZeroDivisionError
        result = a / b
        # keep integers integral when the division is exact
        if isinstance(a, int) and isinstance(b, int) and a % b == 0:
            return a // b
        return result
    if op == "%":
        if b == 0:
            raise ZeroDivisionError
        return a % b
    if op == "^":
        return a ** b
    raise ValueError(f"unknown operator {op}")


# ==============================================================================
# 6. INTERMEDIATE CODE GENERATION  (three-address code + quadruples)
# ==============================================================================


@dataclass
class Quad:
    """A quadruple: (operator, argument 1, argument 2, result)."""
    op: str
    arg1: Optional[str]
    arg2: Optional[str]
    result: str

    def to_tac(self) -> str:
        """Render the quadruple as a three-address instruction."""
        if self.op == "=":
            return f"{self.result} = {self.arg1}"
        if self.op == "uminus":
            return f"{self.result} = -{self.arg1}"
        if self.op == "print":
            return f"print {self.arg1}"
        if self.op == "input":
            return f"input {self.result}"
        return f"{self.result} = {self.arg1} {self.op} {self.arg2}"


class CodeGenerator:
    """
    Syntax-directed translation of the AST into three-address code.

    Each expression node carries a synthesised attribute `place`, the name of
    the temporary (or variable, or literal) holding its value. Temporaries are
    numbered t1, t2, ... by newtemp().
    """

    def __init__(self, table: SymbolTable):
        self.table = table
        self.code: List[Quad] = []
        self._temp_count = 0

    def newtemp(self) -> str:
        self._temp_count += 1
        return f"t{self._temp_count}"

    @property
    def temp_count(self) -> int:
        return self._temp_count

    def emit(self, op: str, arg1: Optional[str], arg2: Optional[str],
             result: str) -> None:
        self.code.append(Quad(op, arg1, arg2, result))

    # -- driver ---------------------------------------------------------------
    def generate(self, prog: Program) -> List[Quad]:
        for stmt in prog.statements:
            self._stmt(stmt)
        return self.code

    def _stmt(self, node: Node) -> None:
        if isinstance(node, Assign):
            place = self._expr(node.expr)
            self.emit("=", place, None, node.name)
        elif isinstance(node, Print):
            place = self._expr(node.expr)
            self.emit("print", place, None, "-")
        elif isinstance(node, Input):
            self.emit("input", None, None, node.name)

    def _expr(self, node: Node) -> str:
        """Returns the `place` attribute of the expression."""
        if isinstance(node, Num):
            return str(node.value)

        if isinstance(node, Var):
            return node.name

        if isinstance(node, UnaryOp):
            operand = self._expr(node.operand)
            temp = self.newtemp()
            self.emit("uminus", operand, None, temp)
            return temp

        if isinstance(node, BinOp):
            left = self._expr(node.left)
            right = self._expr(node.right)
            temp = self.newtemp()
            self.emit(node.op, left, right, temp)
            return temp

        raise ValueError(f"cannot generate code for {node!r}")

    # -- listings -------------------------------------------------------------
    def render_tac(self) -> str:
        width = len(str(len(self.code)))
        return "\n".join(f"{i:>{width}}:  {q.to_tac()}"
                         for i, q in enumerate(self.code, start=1))

    def render_quads(self) -> str:
        head = f"{'#':>3}  {'op':<8}{'arg1':<12}{'arg2':<12}{'result':<10}"
        lines = [head, "-" * len(head)]
        for i, q in enumerate(self.code, start=1):
            a1 = "-" if q.arg1 is None else q.arg1
            a2 = "-" if q.arg2 is None else q.arg2
            lines.append(f"{i:>3}  {q.op:<8}{a1:<12}{a2:<12}{q.result:<10}")
        return "\n".join(lines)


# ==============================================================================
# 7. TAC INTERPRETER  (back end stand-in, so the demo produces real output)
# ==============================================================================


class TACRuntimeError(RuntimeError):
    """Runtime failure annotated with the TAC instruction that caused it."""

    def __init__(self, message: str, instruction: int, quad: Quad):
        self.instruction = instruction
        self.quad = quad
        super().__init__(message)


def run_tac(code: List[Quad], input_fn=input) -> List[str]:
    """
    Execute the three-address code on a simple virtual machine whose store maps
    names (variables and temporaries) to numbers. This stands in for a real
    back end and lets the project show that the generated IR is correct.
    """
    store: Dict[str, Any] = {}
    output: List[str] = []

    def value_of(operand: str) -> Any:
        if operand in store:
            return store[operand]
        try:
            return int(operand)
        except ValueError:
            pass
        try:
            return float(operand)
        except ValueError:
            raise RuntimeError(f"undefined operand '{operand}' in generated code")

    for instruction, quad in enumerate(code, start=1):
        if quad.op == "=":
            store[quad.result] = value_of(quad.arg1)
        elif quad.op == "uminus":
            store[quad.result] = -value_of(quad.arg1)
        elif quad.op == "print":
            output.append(format_number(value_of(quad.arg1)))
        elif quad.op == "input":
            try:
                entered = float(input_fn(f"{quad.result} = ").strip())
            except ValueError as exc:
                raise RuntimeError(
                    f"input for '{quad.result}' must be a number") from exc
            store[quad.result] = int(entered) if entered.is_integer() else entered
        else:
            try:
                store[quad.result] = apply_op(quad.op,
                                              value_of(quad.arg1),
                                              value_of(quad.arg2))
            except (ZeroDivisionError, OverflowError) as exc:
                raise TACRuntimeError(str(exc), instruction, quad) from exc
    return output


def format_number(v: Any) -> str:
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, float):
        return f"{v:.6g}"
    return str(v)


# ==============================================================================
# 8. DRIVER
# ==============================================================================


def banner(title: str) -> str:
    return f"\n{'=' * 72}\n {title}\n{'=' * 72}"


def compile_source(source: str, source_name: str = "<stdin>",
                   show: Optional[set] = None, optimise: bool = False,
                   execute: bool = False) -> int:
    """Run every phase in order. Returns a process exit code."""
    show = show or {"tac"}
    reporter = ErrorReporter(source_name, source.splitlines())

    # ---- Phase 1: lexical analysis
    lexer = Lexer(source, reporter)
    tokens = lexer.tokenize()
    if "tokens" in show:
        print(banner("PHASE 1 - LEXICAL ANALYSIS (token stream)"))
        print(f"{'#':>3}  {'Type':<10}{'Lexeme':<14}{'Value':<12}{'Line:Col'}")
        print("-" * 56)
        for i, t in enumerate(tokens, start=1):
            val = "-" if t.value is None else str(t.value)
            print(f"{i:>3}  {t.type:<10}{t.lexeme:<14}{val:<12}{t.line}:{t.col}")
        print(f"\nTotal tokens: {len(tokens)} (including EOF)")

    if reporter.has_errors:
        reporter.dump()
        return 1

    # ---- Phase 2: syntax analysis
    parser = Parser(tokens, reporter)
    ast = parser.parse_program()
    if reporter.has_errors:
        reporter.dump()
        return 1
    if "ast" in show:
        print(banner("PHASE 2 - SYNTAX ANALYSIS (abstract syntax tree)"))
        print(render_ast(ast).rstrip())

    # ---- Phase 3: semantic analysis
    analyser = SemanticAnalyser(reporter)
    table = analyser.analyse(ast)
    if reporter.has_errors:
        reporter.dump()
        return 1
    if "symtab" in show:
        print(banner("PHASE 3 - SEMANTIC ANALYSIS (symbol table)"))
        print(table.render())

    # ---- Optional optimisation
    if optimise:
        ast = fold_constants(ast)
        if "ast" in show:
            print(banner("OPTIMISATION - AST after constant folding"))
            print(render_ast(ast).rstrip())

    # ---- Phase 4: intermediate code generation
    gen = CodeGenerator(table)
    code = gen.generate(ast)
    if "tac" in show:
        print(banner("PHASE 4 - INTERMEDIATE CODE (three-address code)"))
        print(gen.render_tac())
        print(f"\nInstructions: {len(code)}   Temporaries used: {gen.temp_count}")
    if "quads" in show:
        print(banner("PHASE 4b - QUADRUPLE TABLE"))
        print(gen.render_quads())

    # ---- Execution of the IR
    if execute:
        print(banner("EXECUTION OF THE GENERATED CODE"))
        try:
            for line in run_tac(code):
                print(line)
        except (RuntimeError, ZeroDivisionError) as exc:
            print(f"Execution error: {exc}", file=sys.stderr)
            return 1

    return 0


DEMO_SOURCE = """\
// CALC demo program
radius = 7;
pi     = 3.14159;
area   = pi * radius ^ 2;
perim  = 2 * pi * radius;
ratio  = area / perim;
shift  = -(radius - 10) * 3 + 4 % 3;
print area;
print perim;
print ratio;
print shift;
"""


USAGE = __doc__


def main(argv: List[str]) -> int:
    args = argv[1:]
    if not args or "-h" in args or "--help" in args:
        print(USAGE)
        return 0

    flags = {a for a in args if a.startswith("--")}
    files = [a for a in args if not a.startswith("-")]

    show = set()
    for name in ("tokens", "ast", "symtab", "tac", "quads"):
        if f"--{name}" in flags:
            show.add(name)
    if "--all" in flags:
        show = {"tokens", "ast", "symtab", "tac", "quads"}
    if not show:
        show = {"tac"}

    execute = "--run" in flags or "--all" in flags
    optimise = "--opt" in flags

    if "--demo" in flags:
        print("Source program:\n")
        for i, line in enumerate(DEMO_SOURCE.splitlines(), start=1):
            print(f"  {i:>2} | {line}")
        return compile_source(DEMO_SOURCE, "demo.calc",
                              show or {"tac"}, optimise, execute)

    if not files:
        print("error: no input file (try --demo or --help)", file=sys.stderr)
        return 2

    try:
        with open(files[0], "r", encoding="utf-8") as fh:
            source = fh.read()
    except OSError as exc:
        print(f"error: cannot read {files[0]}: {exc}", file=sys.stderr)
        return 2

    return compile_source(source, files[0], show, optimise, execute)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
