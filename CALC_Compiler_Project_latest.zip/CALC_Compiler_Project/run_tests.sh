#!/usr/bin/env bash
# ============================================================================
#  run_tests.sh -- regression runner for the CALC mini compiler
#  Runs every program in tests/ through the Python reference implementation
#  and checks the observed output against the expected values.
# ============================================================================
set -u
cd "$(dirname "$0")"

CC="python3 src/calc_compiler.py"
pass=0
fail=0

check() {           # check <label> <expected> <actual>
    if [ "$2" == "$3" ]; then
        echo "  PASS  $1"
        pass=$((pass + 1))
    else
        echo "  FAIL  $1"
        echo "        expected: $2"
        echo "        actual  : $3"
        fail=$((fail + 1))
    fi
}

run_out() {         # run_out <file> -> space separated program output
    $CC "$1" --run 2>/dev/null | sed -n '/EXECUTION OF THE GENERATED CODE/,$p' \
        | tail -n +3 | tr '\n' ' ' | sed 's/ *$//'
}

echo "=== Group 1: arithmetic, variables, assignment ==="
check "t1 basic operators" "14 6 40 2.5 2" "$(run_out tests/t1_basic.calc)"

echo "=== Group 2: precedence and associativity ==="
check "t2 precedence" "14 20 512 75 -9 0.125 2" "$(run_out tests/t2_precedence.calc)"

echo "=== Group 3: constant folding ==="
check "t3 values unchanged by --opt" "26 26" \
      "$($CC tests/t3_folding.calc --opt --run 2>/dev/null | tail -2 | tr '\n' ' ' | sed 's/ *$//')"
before=$($CC tests/t3_folding.calc --tac 2>/dev/null | grep -c '^ *[0-9]*: ')
after=$($CC tests/t3_folding.calc --tac --opt 2>/dev/null | grep -c '^ *[0-9]*: ')
if [ "$after" -lt "$before" ]; then
    echo "  PASS  t3 folding shrinks the code ($before -> $after instructions)"
    pass=$((pass + 1))
else
    echo "  FAIL  t3 folding did not shrink the code ($before -> $after)"
    fail=$((fail + 1))
fi

echo "=== Group 4: error detection (each must exit non-zero) ==="
for f in tests/t4_lexical_error.calc tests/t5_syntax_error.calc tests/t6_semantic_error.calc; do
    $CC "$f" >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo "  PASS  $(basename "$f") rejected"
        pass=$((pass + 1))
    else
        echo "  FAIL  $(basename "$f") was accepted"
        fail=$((fail + 1))
    fi
done

echo "=== Group 5: each phase produces a listing ==="
for flag in --tokens --ast --symtab --tac --quads; do
    n=$($CC tests/t1_basic.calc $flag 2>/dev/null | wc -l)
    if [ "$n" -gt 5 ]; then
        echo "  PASS  $flag listing produced"
        pass=$((pass + 1))
    else
        echo "  FAIL  $flag listing empty"
        fail=$((fail + 1))
    fi
done

echo
echo "------------------------------------------"
echo " $pass passed, $fail failed"
echo "------------------------------------------"
[ "$fail" -eq 0 ] || exit 1
