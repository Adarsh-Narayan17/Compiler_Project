const form = document.querySelector("#calcForm");
const fieldsHost = document.querySelector("#expressionFields");
const preview = document.querySelector("#expressionPreview");
const errorMessage = document.querySelector("#errorMessage");
const results = document.querySelector("#results");
const continuePanel = document.querySelector("#continuePanel");
const restartButton = document.querySelector("#restartButton");
const addOperationButton = document.querySelector("#addOperation");
const removeOperationButton = document.querySelector("#removeOperation");
const operatorOptions = [
  ["+", "Add (+)"], ["-", "Subtract (−)"], ["*", "Multiply (×)"],
  ["/", "Divide (÷)"], ["%", "Remainder (%)"], ["^", "Power (^)"],
];
const operatorSymbols = {"+": "+", "-": "−", "*": "×", "/": "÷", "%": "%", "^": "^"};
let operationCount = 1;

function names() {
  return Array.from({length: operationCount + 1}, (_, index) => String.fromCharCode(97 + index));
}

function buildFields() {
  const oldValues = Array.from(fieldsHost.querySelectorAll(".value-input"), (field) => field.value);
  const oldOperators = Array.from(fieldsHost.querySelectorAll(".operator-select"), (field) => field.value);
  fieldsHost.replaceChildren();
  const variables = names();

  variables.forEach((variable, index) => {
    const label = document.createElement("label");
    label.className = "field operand-field";
    const title = document.createElement("span");
    title.textContent = `Value ${index + 1} `;
    const variableName = document.createElement("em");
    variableName.textContent = variable;
    title.append(variableName);
    const input = document.createElement("input");
    input.className = "value-input";
    input.dataset.name = variable;
    input.type = "text";
    input.inputMode = "decimal";
    input.autocomplete = "off";
    input.placeholder = index === 0 ? "e.g. 20" : "e.g. 4";
    input.value = oldValues[index] || "";
    input.setAttribute("aria-label", `Value ${index + 1}`);
    input.addEventListener("input", () => { clearInputError(variable); updatePreview(); });
    label.append(title, input);
    fieldsHost.append(label);

    if (index < operationCount) {
      const operatorLabel = document.createElement("label");
      operatorLabel.className = "field operator-field";
      const operatorTitle = document.createElement("span");
      operatorTitle.textContent = `Operation ${index + 1}`;
      const select = document.createElement("select");
      select.className = "operator-select";
      select.dataset.index = String(index);
      select.setAttribute("aria-label", `Operation ${index + 1}`);
      operatorOptions.forEach(([value, text]) => {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = text;
        select.append(option);
      });
      select.value = oldOperators[index] || "+";
      select.addEventListener("change", updatePreview);
      operatorLabel.append(operatorTitle, select);
      fieldsHost.append(operatorLabel);
    }
  });

  addOperationButton.disabled = operationCount >= 5;
  removeOperationButton.hidden = operationCount <= 1;
  updatePreview();
}

function values() {
  return Array.from(fieldsHost.querySelectorAll(".value-input"), (field) => field.value);
}

function operators() {
  return Array.from(fieldsHost.querySelectorAll(".operator-select"), (field) => field.value);
}

function makeExpression() {
  const inputValues = values();
  const ops = operators();
  const parts = [];
  inputValues.forEach((value, index) => {
    parts.push(value || names()[index]);
    if (ops[index]) parts.push(operatorSymbols[ops[index]]);
  });
  return parts.join(" ");
}

function updatePreview() {
  preview.textContent = makeExpression(true);
}

function clearInputError(fieldName) {
  const input = Array.from(fieldsHost.querySelectorAll("input,select"))
    .find((field) => field.dataset.name === fieldName);
  if (input) {
    input.classList.remove("input-error");
    input.removeAttribute("aria-invalid");
    const note = input.parentElement.querySelector(".field-error");
    if (note) note.remove();
  }
  errorMessage.hidden = true;
}

function markInputError(fieldName, message) {
  const input = Array.from(fieldsHost.querySelectorAll("input,select"))
    .find((field) => field.dataset.name === fieldName);
  if (!input) return;
  input.classList.add("input-error");
  input.setAttribute("aria-invalid", "true");
  let note = input.parentElement.querySelector(".field-error");
  if (!note) {
    note = document.createElement("small");
    note.className = "field-error";
    input.after(note);
  }
  note.textContent = message;
}

function addCell(row, text, tag = "td") {
  const cell = document.createElement(tag);
  cell.textContent = text;
  row.append(cell);
}

function renderTokens(tokens) {
  const table = document.createElement("table");
  table.className = "token-table";
  const header = document.createElement("tr");
  ["#", "TYPE", "LEXEME", "LINE:COL"].forEach((name) => addCell(header, name, "th"));
  const thead = document.createElement("thead");
  thead.append(header);
  const tbody = document.createElement("tbody");
  tokens.forEach((token, index) => {
    const row = document.createElement("tr");
    [String(index + 1), token.type, token.lexeme, `${token.line}:${token.col}`]
      .forEach((value) => addCell(row, value));
    tbody.append(row);
  });
  table.append(thead, tbody);
  const target = document.querySelector("#tokensOutput");
  if (target.tagName === "TABLE") target.replaceWith(table);
  else target.replaceWith(table);
  table.id = "tokensOutput";
}

function renderSymbols(entries) {
  const table = document.createElement("table");
  table.className = "symbol-table";
  const thead = document.createElement("thead");
  const header = document.createElement("tr");
  ["NAME", "TYPE", "ADDRESS", "WRITES", "READS"].forEach((name) => addCell(header, name, "th"));
  thead.append(header);
  const tbody = document.createElement("tbody");
  entries.forEach((entry) => {
    const row = document.createElement("tr");
    [entry.name, entry.type, String(entry.address), String(entry.writes), String(entry.reads)]
      .forEach((value) => addCell(row, value));
    tbody.append(row);
  });
  table.append(thead, tbody);
  document.querySelector("#symbolsOutput").replaceChildren(table);
}

function renderCodeLines(target, text = "", errorLine, lineClass) {
  target.replaceChildren();
  if (!text) return;
  text.split("\n").forEach((line, index) => {
    const row = document.createElement("span");
    row.className = `${lineClass}${index + 1 === errorLine ? " is-error" : ""}`;
    const number = document.createElement("span");
    number.className = "line-number";
    number.textContent = String(index + 1);
    row.append(number, document.createTextNode(line));
    target.append(row);
  });
}

function showErrorBanner(phase, message, line, column) {
  document.querySelector("#resultBanner").classList.add("has-error");
  document.querySelector("#resultLabel").textContent = `${phase} error`;
  document.querySelector("#resultValue").textContent = "Error";
  const location = line ? ` at line ${line}${column ? `, column ${column}` : ""}` : "";
  document.querySelector("#resultCaption").textContent = `${phase}${location}: ${message}`;
  document.querySelector("#runMark").textContent = "!";
  const errorPanel = document.querySelector("#resultError");
  errorPanel.textContent = `${phase} error${location}: ${message}`;
  errorPanel.hidden = false;
}

function resetPhaseHighlight() {
  document.querySelectorAll(".phase-card").forEach((card) => {
    card.classList.remove("is-error");
    card.open = false;
  });
}

function renderCompilerError(data) {
  const failure = data.error;
  const phase = failure.phase;
  resetPhaseHighlight();
  document.querySelector("#resultBanner").classList.remove("has-error");
  showErrorBanner(phase, failure.message, failure.line, failure.col);
  renderTokens(data.tokens || []);
  document.querySelector("#astOutput").textContent = data.ast || "";
  if (data.symbols) renderSymbols(data.symbols);
  else document.querySelector("#symbolsOutput").replaceChildren();
  renderCodeLines(document.querySelector("#tacOutput"), data.tac || "", failure.tacLine, "tac-line");
  document.querySelector("#tacMeta").textContent = "";
  renderCodeLines(document.querySelector("#sourceOutput"), data.source || "", failure.line, "source-line");
  document.querySelector("#executionOutput").textContent = "Compilation stopped before execution.";
  const target = document.querySelector(`.phase-card[data-phase="${phase}"]`);
  if (target) {
    target.classList.add("is-error");
    target.open = true;
  }
  errorMessage.hidden = true;
  results.hidden = false;
  continuePanel.hidden = false;
  restartButton.hidden = true;
  results.scrollIntoView({behavior: "smooth", block: "start"});
}

function renderResult(data) {
  const failure = data.error || null;
  resetPhaseHighlight();
  const resultBanner = document.querySelector("#resultBanner");
  resultBanner.classList.toggle("has-error", Boolean(failure));
  document.querySelector("#resultLabel").textContent = failure ? "Execution error" : "Program result";
  document.querySelector("#resultValue").textContent = failure ? "Error" : data.result;
  document.querySelector("#resultCaption").textContent = failure
    ? `${failure.phase}: ${failure.message}`
    : `${data.operation} · ${makeExpression(true)}`;
  document.querySelector("#runMark").textContent = failure ? "!" : "✓";
  const errorPanel = document.querySelector("#resultError");
  errorPanel.hidden = !failure;
  errorPanel.textContent = failure ? `${failure.phase}: ${failure.message}` : "";
  renderTokens(data.tokens);
  document.querySelector("#astOutput").textContent = data.ast;
  renderSymbols(data.symbols);
  renderCodeLines(document.querySelector("#tacOutput"), data.tac, failure?.tacLine, "tac-line");
  document.querySelector("#tacMeta").textContent = `${data.instructionCount} instructions · ${data.temporaryCount} temporary values`;
  renderCodeLines(document.querySelector("#sourceOutput"), data.source, failure?.sourceLine, "source-line");
  document.querySelector("#executionOutput").textContent = failure ? `Error: ${failure.message}` : data.result;
  if (failure) {
    const target = document.querySelector(`.phase-card[data-phase="${failure.phase}"]`);
    if (target) {
      target.classList.add("is-error");
      target.open = true;
    }
      if (failure.field) markInputError(failure.field, failure.message);
  } else {
    document.querySelector('[data-phase="Lexical analysis"]').open = true;
  }
  errorMessage.hidden = true;
  results.hidden = false;
  continuePanel.hidden = false;
  restartButton.hidden = true;
  results.scrollIntoView({behavior: "smooth", block: "start"});
}

addOperationButton.addEventListener("click", () => {
  if (operationCount < 5) {
    operationCount += 1;
    buildFields();
  }
});

removeOperationButton.addEventListener("click", () => {
  if (operationCount > 1) {
    operationCount -= 1;
    buildFields();
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorMessage.hidden = true;
  results.hidden = true;
  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  button.querySelector("span").textContent = "Compiling…";
  try {
    const response = await fetch("/api/calculate", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({values: values(), operators: operators()}),
    });
    const data = await response.json();
    if (data.error && typeof data.error === "object") {
      if (data.tac) renderResult(data);
      else renderCompilerError(data);
      return;
    }
    if (!response.ok) {
      const phase = data.phase || "Input validation";
      const message = data.error || "The calculation could not be compiled.";
      errorMessage.textContent = `${phase} error: ${message}`;
      errorMessage.hidden = false;
      if (data.field) {
        markInputError(data.field, message);
        fieldsHost.querySelector(`[data-name="${data.field}"]`)?.focus();
      }
      return;
    }
    renderResult(data);
  } catch (error) {
    errorMessage.textContent = `Application error: ${error.message}`;
    errorMessage.hidden = false;
  } finally {
    button.disabled = false;
    button.querySelector("span").textContent = "Compile & calculate";
  }
});

document.querySelector("#continueYes").addEventListener("click", () => {
  results.hidden = true;
  errorMessage.hidden = true;
  fieldsHost.querySelectorAll("input").forEach((field) => { field.value = ""; });
  updatePreview();
  fieldsHost.querySelector("input")?.focus();
  window.scrollTo({top: 0, behavior: "smooth"});
});

document.querySelector("#continueNo").addEventListener("click", () => {
  continuePanel.hidden = true;
  restartButton.hidden = false;
  document.querySelector("#continueMessage").textContent = "Session finished. The calculation remains visible above.";
});

restartButton.addEventListener("click", () => {
  restartButton.hidden = true;
  continuePanel.hidden = false;
  document.querySelector("#continueMessage").textContent = "Perform another calculation?";
  results.hidden = true;
  fieldsHost.querySelectorAll("input").forEach((field) => { field.value = ""; });
  updatePreview();
  fieldsHost.querySelector("input")?.focus();
  window.scrollTo({top: 0, behavior: "smooth"});
});

buildFields();
