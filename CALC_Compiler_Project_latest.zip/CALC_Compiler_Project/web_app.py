#!/usr/bin/env python3
"""Serve the interactive CALC compiler lab using only Python's standard library."""

from __future__ import annotations

import json
import math
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from src.calc_compiler import (
    CodeGenerator,
    ErrorReporter,
    Lexer,
    Parser,
    SemanticAnalyser,
    TACRuntimeError,
    render_ast,
    run_tac,
)


ROOT = Path(__file__).resolve().parent
WEB_ROOT = ROOT / "web"
OPERATORS = {"+", "-", "*", "/", "%", "^"}


class CalculationError(ValueError):
    def __init__(self, message: str, field: str | None = None):
        self.field = field
        super().__init__(message)


def calculate(payload: dict) -> dict:
    raw_values = payload.get("values", [])
    operators = payload.get("operators", [])
    if not isinstance(raw_values, list) or not 2 <= len(raw_values) <= 6:
        raise CalculationError("Enter between two and six numbers.")
    if not isinstance(operators, list) or len(operators) != len(raw_values) - 1:
        raise CalculationError("Each pair of numbers needs one operation.")
    if any(op not in OPERATORS for op in operators):
        raise CalculationError("Choose a valid operation.", "operation")

    values = {}
    names = [chr(ord("a") + index) for index in range(len(raw_values))]
    for name, raw_value in zip(names, raw_values):
        try:
            values[name] = float(raw_value)
        except (TypeError, ValueError) as exc:
            raise CalculationError(f"Enter a valid number for {name.upper()}.", name) from exc
        if not math.isfinite(values[name]):
            raise CalculationError(f"{name.upper()} must be a finite number.", name)

    expression = " ".join(part for pair in zip(names, operators + [None])
                           for part in pair if part is not None)
    source = "\n".join([*(f"input {name};" for name in names),
                        f"print {expression};"])
    reporter = ErrorReporter("web.calc", source.splitlines())
    tokens = Lexer(source, reporter).tokenize()
    if reporter.has_errors:
        err = reporter.errors[0]
        return {"error": {"phase": "Lexical analysis", "message": err.message,
                          "line": err.line, "col": err.col},
                "source": source, "sourceLine": err.line,
                "tokens": [{"type": token.type, "lexeme": token.lexeme,
                            "line": token.line, "col": token.col} for token in tokens]}

    ast = Parser(tokens, reporter).parse_program()
    if reporter.has_errors:
        err = reporter.errors[0]
        return {"error": {"phase": "Syntax analysis", "message": err.message,
                          "line": err.line, "col": err.col},
                "source": source, "sourceLine": err.line,
                "tokens": [{"type": token.type, "lexeme": token.lexeme,
                            "line": token.line, "col": token.col} for token in tokens],
                "ast": render_ast(ast).rstrip()}

    table = SemanticAnalyser(reporter).analyse(ast)
    if reporter.has_errors:
        err = reporter.errors[0]
        return {"error": {"phase": "Semantic analysis", "message": err.message,
                          "line": err.line, "col": err.col},
                "source": source, "sourceLine": err.line,
                "tokens": [{"type": token.type, "lexeme": token.lexeme,
                            "line": token.line, "col": token.col} for token in tokens],
                "ast": render_ast(ast).rstrip(),
                "symbols": [{"name": entry.name, "type": entry.dtype,
                             "address": entry.address, "writes": entry.assignments,
                             "reads": entry.uses} for entry in table.entries.values()]}

    generator = CodeGenerator(table)
    try:
        code = generator.generate(ast)
    except (ValueError, RuntimeError) as exc:
        return {"error": {"phase": "Intermediate code", "message": str(exc)},
                "source": source,
                "tokens": [{"type": token.type, "lexeme": token.lexeme,
                            "line": token.line, "col": token.col} for token in tokens],
                "ast": render_ast(ast).rstrip(),
                "symbols": [{"name": entry.name, "type": entry.dtype,
                             "address": entry.address, "writes": entry.assignments,
                             "reads": entry.uses} for entry in table.entries.values()]}
    result = {
        "source": source.rstrip(),
        "tokens": [
            {"type": token.type, "lexeme": token.lexeme,
             "line": token.line, "col": token.col}
            for token in tokens
        ],
        "ast": render_ast(ast).rstrip(),
        "symbols": [
            {"name": entry.name, "type": entry.dtype,
             "address": entry.address, "writes": entry.assignments,
             "reads": entry.uses}
            for entry in table.entries.values()
        ],
        "tac": generator.render_tac(),
        "quads": generator.render_quads(),
        "instructionCount": len(code),
        "temporaryCount": generator.temp_count,
        "result": "",
        "operation": "Calculation",
        "expression": expression,
    }
    inputs = iter(str(values[name]) for name in names)
    try:
        output = run_tac(code, input_fn=lambda _prompt="": next(inputs))
        result["result"] = output[-1] if output else ""
    except TACRuntimeError as exc:
        operator_name = {"/": "Division by zero", "%": "Remainder by zero",
                         "^": "Invalid power", "+": "Addition error",
                         "-": "Subtraction error", "*": "Multiplication error"}.get(
                             exc.quad.op, "Runtime error")
        divisor = exc.quad.arg2
        field = divisor if divisor in names else None
        result["error"] = {
            "phase": "Execution",
            "message": f"{operator_name} while evaluating {exc.quad.arg1} {exc.quad.op} {exc.quad.arg2}.",
            "field": field,
            "sourceLine": len(names) + 1,
            "tacLine": exc.instruction,
        }
    except RuntimeError as exc:
        result["error"] = {"phase": "Execution", "message": str(exc)}
    return result


class Handler(BaseHTTPRequestHandler):
    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        route = urlparse(self.path).path
        files = {"/": "index.html", "/index.html": "index.html",
                 "/styles.css": "styles.css", "/app.js": "app.js"}
        filename = files.get(route)
        if filename is None:
            self._send(404, b"Not found", "text/plain; charset=utf-8")
            return
        content_type = "text/css; charset=utf-8" if filename.endswith(".css") else "text/javascript; charset=utf-8"
        if filename.endswith(".html"):
            content_type = "text/html; charset=utf-8"
        self._send(200, (WEB_ROOT / filename).read_bytes(), content_type)

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/api/calculate":
            self._send(404, b'{"error":"Not found"}', "application/json; charset=utf-8")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 10_000:
                raise ValueError("Request is empty or too large.")
            payload = json.loads(self.rfile.read(length))
            result = calculate(payload)
            status = 422 if "error" in result else 200
            self._send(status, json.dumps(result).encode(), "application/json; charset=utf-8")
        except CalculationError as exc:
            body = json.dumps({"error": str(exc), "phase": "Input validation",
                               "field": exc.field}).encode()
            self._send(400, body, "application/json; charset=utf-8")
        except (ValueError, json.JSONDecodeError) as exc:
            body = json.dumps({"error": str(exc), "phase": "Input validation"}).encode()
            self._send(400, body, "application/json; charset=utf-8")

    def log_message(self, _format: str, *_args: object) -> None:
        pass


if __name__ == "__main__":
    address = ("127.0.0.1", 8000)
    print(f"CALC Compiler Lab running at http://127.0.0.1:{address[1]}")
    print("Press Ctrl+C to stop.")
    ThreadingHTTPServer(address, Handler).serve_forever()
